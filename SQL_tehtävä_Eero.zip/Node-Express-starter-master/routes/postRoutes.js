const express = require("express");
const router = express.Router();
const postControllers = require("../controllers/postControllers");

router
  .route("/")
  .get(postControllers.getAllPosts)
  .post(postControllers.createNewPost);
router.route("/:id").get(postControllers.getPostById);
router.route("/:id").delete(postControllers.deletePostById);
router.route("/:id").put(postControllers.putPostToId);

module.exports = router;
